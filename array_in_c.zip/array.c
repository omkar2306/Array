#include<stdio.h>
void main()
{
int a[5],i;
printf("please take the element of array\n");
for(i=0;i<5;i++)
{
scanf("%d",&a[i]);
}
printf("print the elements of array\n");
for(i=0;i<5;i++)
{
printf("%d\n",a[i]);
}
}
