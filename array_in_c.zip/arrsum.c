#include<stdio.h>
void main()
{
int a[5],i,sum=0;

printf("please take numbers\n");
for(i=0;i<5;i++)
{
scanf("%d",&a[i]);
}

for(i=0;i<5;i++)
{
sum=sum+a[i];
}
printf("SUM:->%d",sum);
}
